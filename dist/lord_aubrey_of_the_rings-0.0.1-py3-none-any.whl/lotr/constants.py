HOST = 'the-one-api.dev'
BASEPATH = '/v2'
